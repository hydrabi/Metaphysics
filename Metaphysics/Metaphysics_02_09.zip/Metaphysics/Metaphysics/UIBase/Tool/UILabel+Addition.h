//
//  UILabel+Addition.h
//  Metaphysics
//
//  Created by Hydra on 2017/2/7.
//  Copyright © 2017年 毕志锋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Addition)
@property (nonatomic,assign)CGFloat originalSize;

-(void)setBoldFont;
-(void)setOriginalFont;
@end
