//
//  NSString+Addition.h
//  Metaphysics
//
//  Created by Hydra on 2017/2/1.
//  Copyright © 2017年 毕志锋. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Addition)
+ (NSString *)convertToIconTextWithHexString:(NSString *)hexStr;
@end
