//
//  BottomContentView.h
//  Metaphysics
//
//  Created by Hydra on 2017/1/30.
//  Copyright © 2017年 毕志锋. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BottomTableViewDataSource.h"
@interface BottomContentView : UIView
@property (nonatomic,strong)BottomTableViewDataSource *dataSorce;
@end
